import React from "react";
import { useApp } from "../../../context/AppContext";
import "./Maniobras.css";

const DetalleOrden = ({ orden, onVolver }) => {
  const { toggleEstadoOrden } = useApp(); 

  if (!orden) return <p>No se ha seleccionado ninguna orden.</p>;

  return (
    <div className="detalle-orden">
      <h3>Detalle de Orden #{orden.id}</h3>
      <p><strong>Usuario:</strong> {orden.usuarioNombre}</p>
      <p><strong>Fecha:</strong> {orden.fecha}</p>
      <p>
        <strong>Estado:</strong>{" "}
        <span style={{ color: orden.isEntregado ? "green" : "red" }}>
          {orden.isEntregado ? "Entregado" : "No Entregado"}
        </span>
      </p>

      <button onClick={() => toggleEstadoOrden(orden.id)}>
        Cambiar Estado
      </button>

      <button onClick={onVolver} style={{ marginLeft: "10px" }}>
        Volver
      </button>
    </div>
  );
};

export default DetalleOrden;
