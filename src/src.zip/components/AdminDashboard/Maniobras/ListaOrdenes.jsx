import React, { useState } from "react";
import { useApp } from "../../../context/AppContext";
import "./Maniobras.css";

const ListaOrdenes = ({ onVerDetalle }) => {
  const { ordenes } = useApp(); 
  const [busqueda, setBusqueda] = useState("");

  const filtradas = ordenes.filter((orden) =>
    orden.id.toString().includes(busqueda)
  );

  return (
    <div className="lista-ordenes">
      <h3>Lista de Órdenes</h3>

      <input
        type="text"
        placeholder="Buscar por ID de orden..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {filtradas.map((orden) => (
            <tr key={orden.id}>
              <td>{orden.id}</td>
              <td>{orden.fecha}</td>
              <td style={{ color: orden.isEntregado ? "green" : "red" }}>
                {orden.isEntregado ? "Entregado" : "No Entregado"}
              </td>
              <td>
                <button onClick={() => onVerDetalle(orden)}>VER DETALLE</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListaOrdenes;
