import { useState } from "react";
import "./NewArrivals.css";
import productos from "../../data/data";

function Carrusel({ titulo, productos }) {
  const [indice, setIndice] = useState(0);
  const total = productos.length;

  const siguiente = () => setIndice((indice + 3) % total);
  const anterior = () => setIndice((indice - 3 + total) % total);

  const visibles = productos.slice(indice, indice + 3);
  if (visibles.length < 3) {
    visibles.push(...productos.slice(0, 3 - visibles.length));
  }

  return (
    <div className="carrusel">
      <h2>{titulo}</h2>
      <div className="carrusel-contenido">
        <button onClick={anterior}>⬅</button>

        <div key={indice} className="productos-arrivals">
          {visibles.map((item) => (
            <div key={item.id} className="producto-card">
              <div className="imagen-container">
                <img src={item.image} alt={item.name} />
              </div>
              <div className="info-producto">
                <h3>{item.name}</h3>
                <p>{item.category}</p>
                <span className="precio">{item.price}</span>
              </div>
            </div>
          ))}
        </div>

        <button onClick={siguiente}>➡</button>
      </div>
    </div>
  );
}

export default function NewArrivals() {
//los 6 ids mas altos
  const ultimos6 = [...productos].sort((a, b) => b.id - a.id).slice(0, 6);

  return (
    <section className="new-arrivals">
      <div className="encabezado">
        <div className="linea"></div>
        <h2>Nuevos Productos</h2>
        <p>Recién añadidos a nuestra colección</p>
      </div>

      <Carrusel productos={ultimos6} />
    </section>
  );
}


