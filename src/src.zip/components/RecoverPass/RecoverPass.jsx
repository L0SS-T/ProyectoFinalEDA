import Footer from "../Footer/Footer"
import Header from "../Header/Header"
import RecoverPassForm from "./RecoverPassForm/RecoverPassForm";


const RecoverPass = ()=>{
    return(
        <>
            <Header/>
            <RecoverPassForm/>
            <Footer/>
        </>
    )
}
export default RecoverPass;