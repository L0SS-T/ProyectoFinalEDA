const categorias = [
  "Pulseras",
  "Pendientes",
  "Collares",
  "Conjuntos",
  "Anillos"
];

export default categorias;