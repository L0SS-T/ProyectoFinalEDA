



// ---------------- Anillos ------------------
const anillo10= "https://static.darryring.com/vidoe/drElove/U250612564_8e6864536acc49f4bc50b7bbe4f91516.jpg"
const anillo10_2="https://static.darryring.com/vidoe/drElove/U250916121_c8ea7b9481db45f68cc83fae1949b61a.jpg"

const anillo11= "https://static.darryring.com/vidoe/drElove/U241006903_b037c33628e44ec68377b495365c00b9.jpg"
const anillo11_2= "https://static.darryring.com/vidoe/drElove/U241006847_a3459acdbe984b7e931da93cd5411d47.jpg"

const anillo12= "https://www.floysun.com/cdn/shop/files/tribal-totem-adjustable-beaded-ring-pink-tourmaline-654632.jpg?v=1749731627&width=3000"
const anillo12_2= "https://www.floysun.com/cdn/shop/files/tribal-totem-adjustable-beaded-ring-green-garnet-141339.jpg?v=1749731629&width=3000"

const anillo13= "https://www.floysun.com/cdn/shop/files/satin-floral-wide-ring-hollow-design-in-brushed-925-sterling-silver-495855.jpg?v=1750133938&width=3000"
const anillo13_2= "https://www.floysun.com/cdn/shop/files/satin-floral-wide-ring-hollow-design-in-brushed-925-sterling-silver-618919.jpg?v=1750133939&width=3000"

const anillo14= "https://www.floysun.com/cdn/shop/files/17978446554_276917411.jpg?v=1756296395&width=3000"
const anillo14_2= "https://www.floysun.com/cdn/shop/files/woven-multi-layer-freshwater-pearl-ring-435662.jpg?v=1756296425&width=3000"

const anillo15= "https://tedandmag.com/cdn/shop/files/IMG_6288.jpg?v=1720790189"
const anillo15_2= "https://tedandmag.com/cdn/shop/files/IMG_6306.jpg?v=1720790189"

const anillo16= "https://tedandmag.com/cdn/shop/files/IMG_6409.jpg?v=1721398273"
const anillo16_2= "https://tedandmag.com/cdn/shop/files/IMG_6392.jpg?v=1721393167"

const anillo17= "https://tedandmag.com/cdn/shop/files/IMG_6852.jpg?v=1725627437"
const anillo17_2= "https://tedandmag.com/cdn/shop/files/IMG_6876.jpg?v=1725627437"

const anillo18= "https://tedandmag.com/cdn/shop/products/39D8DA2B-2439-456E-A037-F29283CD54C3.jpg?v=1669017854"
const anillo18_2= "https://tedandmag.com/cdn/shop/products/BB361E61-40A8-4C4F-82E0-E37D7CE51A73.jpg?v=1669017854"

const anillo19= "https://www.floysun.com/cdn/shop/files/engraved-sunflower-adjustable-ring-377879.jpg?v=1750133938&width=3000"
const anillo19_2="https://www.floysun.com/cdn/shop/files/engraved-sunflower-adjustable-ring-602855.jpg?v=1750133938&width=3000"


// ----------- Conjuntos ----------------
const conjunto10="https://www.floysun.com/cdn/shop/files/classic-chanel-inspired-vintage-square-enamel-glazed-pearl-open-ringfloysun-384270.jpg?v=1718152812&width=3000"
const conjunto10_2="https://www.floysun.com/cdn/shop/files/classic-chanel-inspired-vintage-square-enamel-glazed-pearl-open-ring-247720.jpg?v=1729750385&width=3000"

const conjunto11=""
const conjunto11_2=""

const conjunto12=""
const conjunto12_2=""

const conjunto13="https://www.floysun.com/cdn/shop/files/t-shape-irregular-ice-crystal-pink-diamond-pendant-necklacefloysun-8418484.jpg?v=1756117404&width=3000"
const conjunto13_2="https://www.floysun.com/cdn/shop/files/t-shape-irregular-ice-crystal-pink-diamond-stud-earringsfloysun-3935855.jpg?v=1756117400&width=3000"

const conjunto14=""
const conjunto14_2=""

const conjunto15=""
const conjunto15_2=""

const conjunto16=""
const conjunto16_2=""

const conjunto17="https://www.floysun.com/cdn/shop/files/pink-woven-heart-earringsfloysun-2537002.jpg?v=1754479804&width=3000"
const conjunto17_2="https://www.floysun.com/cdn/shop/files/pink-woven-heart-earringsfloysun-2440737.jpg?v=1755173782&width=3000"

const conjunto18=""
const conjunto18_2=""

const conjunto19="https://www.floysun.com/cdn/shop/files/tiger-eye-turquoise-layered-braceletfloysun-5881784.jpg?v=1757745118&width=3000"
const conjunto19_2="https://www.floysun.com/cdn/shop/files/tiger-eye-turquoise-layered-braceletfloysun-1485278.jpg?v=1757745117&width=3000"

// ------------------ Collares -------------
const collar10="https://laboutiquejoyas.com/cdn/shop/files/8_b100f1d1-ac7a-4c3d-a9f8-9c0b0241de26.jpg?v=1721098491"
const collar10_2="https://laboutiquejoyas.com/cdn/shop/files/9_27699110-bf90-4cac-a6b7-46dcd880ca9e.jpg?v=1721098493"

const collar11="https://www.lapericajoyas.pe/cdn/shop/files/COLLARES_WEB-34.jpg?v=1750777268&width=3000"
const collar11_2="https://www.lapericajoyas.pe/cdn/shop/files/Artesanal-14_a1d1e1cb-ef54-4cb4-8d3f-0ebc930c4f7c.jpg?v=1750953735&width=3000"

const collar12="https://www.lapericajoyas.pe/cdn/shop/files/PULSERA_WEB-22.jpg?v=1750343594&width=3000"
const collar12_2="https://www.lapericajoyas.pe/cdn/shop/files/Artesanal-2_ca868e7d-53ae-4672-9eb7-c2a126a6d76b.jpg?v=1750959072&width=3000"

const collar13="https://static.darryring.com/vidoe/drElove/U250511592_b2b6b96689ea43098b13ce0e2ebab3ed.jpg"
const collar13_2="https://static.darryring.com/vidoe/drElove/U250613275_b6e71bbbeac140c4b387616084188065.jpg"

const collar14="https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dw93ba0820/images/P22837783/P22837783-25-21.jpg?sw=2000&sm=fit&q=95"
const collar14_2="https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dw74793955/images/P22837783/P22837783-25-28.jpg?sw=2000&sm=fit&q=95"

const collar15="https://www.lapericajoyas.pe/cdn/shop/files/COLLARES_WEB-26.jpg?v=1750777338&width=3000"
const collar15_2="https://www.lapericajoyas.pe/cdn/shop/files/Artesanal-18_719bbab5-c78c-48dd-879c-9e1634af8c89.jpg?v=1750952949&width=3000"

const collar16="https://www.lapericajoyas.pe/cdn/shop/files/MG_0050_80f35225-8eda-42d8-b285-d5d005acf07b.jpg?v=1732976614&width=3000"
const collar16_2="https://www.lapericajoyas.pe/cdn/shop/files/MG_0314.jpg?v=1735238353&width=3000"

const collar17="https://www.lapericajoyas.pe/cdn/shop/files/MG_0154_df773c9f-72f1-499e-94d0-5d10d0c1dfdd.jpg?v=1701140841&width=3000"
const collar17_2="https://www.lapericajoyas.pe/cdn/shop/files/MG_0305_002c5553-dcf5-41bb-b01e-870cf9d496c4.jpg?v=1701140916&width=3000"

const collar18="https://laboutiquejoyas.com/cdn/shop/files/251_7f3c1f4c-e0c9-41c4-8d7f-2a768f375252.jpg?v=1721318316"
const collar18_2="https://laboutiquejoyas.com/cdn/shop/files/252_11ff26ff-f5e9-4ee3-af00-3e616871adae.jpg?v=1721318319"

const collar19="https://laboutiquejoyas.com/cdn/shop/files/DSC_9079.png?v=1752877343"
const collar19_2="https://laboutiquejoyas.com/cdn/shop/files/Febrero2025-LaBoutique34.jpg?v=1752877343"

// ---------- Pendientes ------------
const pendiente10="https://www.lapericajoyas.pe/cdn/shop/files/MG_0011_1.jpg?v=1732982403&width=3000"
const pendiente10_2="https://www.lapericajoyas.pe/cdn/shop/files/MG_0130_1_671de277-6aa2-4163-a7c0-77ac6bd7bfff.jpg?v=1732982427&width=3000"

const pendiente11="https://www.floysun.com/cdn/shop/files/wishing-tower-earrings-symbolic-jewelry-of-dreams-hopefloysun-4591906.jpg?v=1755695074&width=3000"
const pendiente11_2="https://www.floysun.com/cdn/shop/files/wishing-tower-earrings-symbolic-jewelry-of-dreams-hopefloysun-7240235.jpg?v=1755695040&width=3000"

const pendiente12="https://www.lapericajoyas.pe/cdn/shop/files/MG_0010_9755ddaf-9c8f-45a8-8e97-019180d6b327.jpg?v=1734017242&width=3000"
const pendiente12_2="https://www.lapericajoyas.pe/cdn/shop/files/MG_0040_574fd35b-2d76-4390-befc-5353bafd5a75.jpg?v=1734017242&width=3000"

const pendiente13="https://www.floysun.com/cdn/shop/files/crystal-dewdrop-earrings-gold-705683.jpg?v=1750427690&width=3000"
const pendiente13_2="https://www.floysun.com/cdn/shop/files/crystal-dewdrop-earrings-gold-781698.jpg?v=1750427691&width=3000"

const pendiente14="https://treeoflife.com.au/cdn/shop/files/MS347GOLRAINE_2048x2048.jpg?v=1737525190"
const pendiente14_2="https://treeoflife.com.au/cdn/shop/files/MS347GOLRAINE-1_2048x2048.jpg?v=1740011876"

const pendiente15="https://bycharlotte.com.au/cdn/shop/files/e324s925-silver-startlight_earrings-silver-1.jpg?v=1755849746&width=1440"
const pendiente15_2="https://bycharlotte.com.au/cdn/shop/files/e324s925-silver-starlight-earrings-silver--2.jpg?v=1755849746&width=1440"

const pendiente16="https://efgdesigns.com/cdn/shop/products/CLE20083Y4_a0e2dca5-6428-4879-a874-01e31a5f26f9.jpg?v=1584557259&width=800"
const pendiente16_2="https://efgdesigns.com/cdn/shop/products/CLE20083Y4-2.jpg?v=1660592775&width=800"

const pendiente17="https://www.floysun.com/cdn/shop/files/vintage-swing-geometric-tassel-earrings-648779.jpg?v=1750830020&width=3000"
const pendiente17_2="https://www.floysun.com/cdn/shop/files/vintage-swing-geometric-tassel-earrings-264991.jpg?v=1750830020&width=3000"

const pendiente18="https://www.floysun.com/cdn/shop/files/engraved-brushed-square-filigree-stud-earrings-921442.jpg?v=1750133936&width=3000"
const pendiente18_2="https://www.floysun.com/cdn/shop/files/engraved-brushed-square-filigree-stud-earrings-759389.jpg?v=1750133936&width=3000"

const pendiente19="https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dw8a155b9e/images/P18636703/P18636703-25-22.jpg?sw=2000&sm=fit&q=95"
const pendiente19_2="https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dw32bc7395/images/P18636703/P18636703-25-27.jpg?sw=2000&sm=fit&q=95"


// ------ Pulseras ----------

const pulsera10 = "";
const pulsera10_2 = "";

const pulsera11 = "";
const pulsera11_2 = "";

const pulsera12 = "";
const pulsera12_2 = "";

const pulsera13 = "";
const pulsera13_2 = "";

const pulsera14 = "";
const pulsera14_2 = "";

const pulsera15 = "";
const pulsera15_2 = "";

const pulsera16 = "";
const pulsera16_2 = "";

const pulsera17 = "https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dw51de7031/images/P18655360/P18655360-1-21.jpg?sw=2000&sm=fit&q=95";
const pulsera17_2 = "https://www.michaelhill.com.au/dw/image/v2/AANC_PRD/on/demandware.static/-/Sites-MHJ_Master/default/dwcb4604cd/images/P18655360/P18655360-1-27.jpg?sw=2000&sm=fit&q=95";

const pulsera18 = "";
const pulsera18_2 = "";

const pulsera19 = "";
const pulsera19_2 = "";

const productos = [
  // 🟢 Pulseras
  { id: 21, name: "Pulsera artesanal de piedras", category: "Pulseras", type: "artesanal", price: "$22.00", stock: 40, ventas: 97, image: pulsera10, simage: pulsera10_2 },
  { id: 22, name: "Pulsera de cuero clásica", category: "Pulseras", type: "convencional", price: "$27.00", stock: 55, ventas: 143, image: pulsera11, simage: pulsera11_2 },
  { id: 23, name: "Pulsera de plata fina", category: "Pulseras", type: "de lujo", price: "$95.00", stock: 12, ventas: 48, image: pulsera12, simage: pulsera12_2 },
  { id: 24, name: "Pulsera con dijes dorados", category: "Pulseras", type: "casual", price: "$33.00", stock: 48, ventas: 120, image: pulsera13, simage: pulsera13_2 },
  { id: 25, name: "Pulsera artesanal con cuentas", category: "Pulseras", type: "convencional", price: "$30.00", stock: 36, ventas: 65, image: pulsera14, simage: pulsera14_2 },
  { id: 26, name: "Pulsera de lujo con esmeralda", category: "Pulseras", type: "convencional", price: "$135.00", stock: 8, ventas: 33, image: pulsera15, simage: pulsera15_2 },
  { id: 27, name: "Pulsera de hilo doble", category: "Pulseras", type: "convencional", price: "$26.00", stock: 60, ventas: 119, image: pulsera16, simage: pulsera16_2 },
  { id: 28, name: "Pulsera artesanal de cuero", category: "Pulseras", type: "artesanal", price: "$34.00", stock: 42, ventas: 81, image: pulsera17, simage: pulsera17_2 },
  { id: 29, name: "Pulsera rígida de oro rosa", category: "Pulseras", type: "convencional", price: "$145.00", stock: 9, ventas: 56, image: pulsera18, simage: pulsera18_2 },
  { id: 30, name: "Pulsera trenzada artesanal", category: "Pulseras", type: "convencional", price: "$29.00", stock: 50, ventas: 90, image: pulsera19, simage: pulsera19_2 },


  // Pendientes
  { id: 41, name: "Pendiente dorado chuncky", category: "Pendientes", type: "de lujo", price: "$68.00", stock: 20, ventas: 92, image: pendiente10, simage: pendiente10_2 },
  { id: 42, name: "Pendiente artesanal de piedras", category: "Pendientes", type: "artesanal", price: "$36.00", stock: 34, ventas: 77, image: pendiente11, simage: pendiente11_2 },
  { id: 43, name: "Pendiente de aro clásico", category: "Pendientes", type: "casual", price: "$29.00", stock: 49, ventas: 130, image: pendiente12, simage: pendiente12_2 },
  { id: 44, name: "Pendiente con cristal dewdrop", category: "Pendientes", type: "convencional", price: "$82.00", stock: 14, ventas: 61, image: pendiente13, simage: pendiente13_2 },
  { id: 45, name: "Pendiente boho artesanal", category: "Pendientes", type: "convencional", price: "$40.00", stock: 37, ventas: 84, image: pendiente14, simage: pendiente14_2 },
  { id: 46, name: "Pendiente minimalista de plata", category: "Pendientes", type: "convencional", price: "$31.00", stock: 53, ventas: 102, image: pendiente15, simage: pendiente15_2 },
  { id: 47, name: "Pendiente de lujo con cristales", category: "Pendientes", type: "convencional", price: "$95.00", stock: 11, ventas: 47, image: pendiente16, simage: pendiente16_2 },
  { id: 48, name: "Pendiente artesanal vintage", category: "Pendientes", type: "artesanal", price: "$34.00", stock: 40, ventas: 75, image: pendiente17, simage: pendiente17_2 },
  { id: 49, name: "Pendiente con diseño moderno", category: "Pendientes", type: "casual", price: "$38.00", stock: 46, ventas: 111, image: pendiente18, simage: pendiente18_2 },
  { id: 50, name: "Pendiente largo con perlas", category: "Pendientes", type: "convencional", price: "$45.00", stock: 30, ventas: 89, image: pendiente19, simage: pendiente19_2 },

  // 🟣 Collares
  { id: 1, name: "Collar de perlas elegante", category: "Collares", type: "de lujo", price: "$85.00", stock: 18, ventas: 97, image: collar10, simage: collar10_2 },
  { id: 2, name: "Collar dorado arbol de la abundancia", category: "Collares", type: "casual", price: "$35.00", stock: 42, ventas: 134, image: collar11, simage: collar11_2 },
  { id: 3, name: "Collar artesanal de piedras", category: "Collares", type: "artesanal", price: "$48.00", stock: 27, ventas: 72, image: collar12, simage: collar12_2 },
  { id: 4, name: "Collar casino con charms", category: "Collares", type: "convencional", price: "$29.00", stock: 54, ventas: 120, image: collar13, simage: collar13_2 },
  { id: 5, name: "Collar con diamante", category: "Collares", type: "de lujo", price: "$160.00", stock: 10, ventas: 40, image: collar14, simage: collar14_2 },
  { id: 6, name: "Collar sol y luna", category: "Collares", type: "convencional", price: "$52.00", stock: 33, ventas: 61, image: collar15, simage: collar15_2 },
  { id: 7, name: "Collar chuncky dorado", category: "Collares", type: "convencional", price: "$98.00", stock: 14, ventas: 85, image: collar16, simage: collar16_2 },
  { id: 8, name: "Collar clips domino plateado", category: "Collares", type: "casual", price: "$42.00", stock: 45, ventas: 110, image: collar17, simage: collar17_2 },
  { id: 9, name: "Collar set 3 amores", category: "Collares", type: "convencional", price: "$115.00", stock: 9, ventas: 60, image: collar18, simage: collar18_2 },
  { id: 10, name: "Collar cuarzo cafe", category: "Collares", type: "convencional", price: "$40.00", stock: 38, ventas: 75, image: collar19, simage: collar19_2 },

  // 🔴 Conjuntos
  { id: 31, name: "Conjunto de brazalete y anillo vintage", category: "Conjuntos", type: "de lujo", price: "$140.00", stock: 10, ventas: 64, image: conjunto10, simage: conjunto10_2 },
  { id: 32, name: "Conjunto artesanal boho", category: "Conjuntos", type: "artesanal", price: "$55.00", stock: 28, ventas: 80, image: conjunto11, simage: conjunto11_2 },
  { id: 33, name: "Conjunto dorado casual", category: "Conjuntos", type: "casual", price: "$49.00", stock: 37, ventas: 104, image: conjunto12, simage: conjunto12_2 },
  { id: 34, name: "Conjunto de lujo con cristales", category: "Conjuntos", type: "convencional", price: "$180.00", stock: 6, ventas: 40, image: conjunto13, simage: conjunto13_2 },
  { id: 35, name: "Conjunto artesanal de plata", category: "Conjuntos", type: "convencional", price: "$62.00", stock: 24, ventas: 73, image: conjunto14, simage: conjunto14_2 },
  { id: 36, name: "Conjunto de collar y anillo casual", category: "Conjuntos", type: "convencional", price: "$52.00", stock: 41, ventas: 99, image: conjunto15, simage: conjunto15_2 },
  { id: 37, name: "Conjunto de lujo con diamantes", category: "Conjuntos", type: "de lujo", price: "$210.00", stock: 5, ventas: 27, image: conjunto16, simage: conjunto16_2 },
  { id: 38, name: "Conjunto artesanal rosado", category: "Conjuntos", type: "convencional", price: "$58.00", stock: 32, ventas: 88, image: conjunto17, simage: conjunto17_2 },
  { id: 39, name: "Conjunto elegante casual", category: "Conjuntos", type: "casual", price: "$47.00", stock: 44, ventas: 105, image: conjunto18, simage: conjunto18_2 },
  { id: 40, name: "Conjunto artesanal de piedras", category: "Conjuntos", type: "convencional", price: "$195.00", stock: 7, ventas: 52, image: conjunto19, simage: conjunto19_2 },

  // 🔵 Anillos
  { id: 11, name: "Anillo de compromiso de oro", category: "Anillos", type: "de lujo", price: "$120.00", stock: 8, ventas: 57, image: anillo10, simage: anillo10_2 },
  { id: 12, name: "Anillo de compromiso plateado", category: "Anillos", type: "de lujo", price: "$28.00", stock: 61, ventas: 140, image: anillo11, simage: anillo11_2 },
  { id: 13, name: "Anillo artesanal", category: "Anillos", type: "artesanal", price: "$38.00", stock: 37, ventas: 77, image: anillo12, simage: anillo12_2 },
  { id: 14, name: "Anillo plateado ancho", category: "Anillos", type: "convencional", price: "$150.00", stock: 11, ventas: 44, image: anillo13, simage: anillo13_2 },
  { id: 15, name: "Anillo de perlas", category: "Anillos", type: "convencional", price: "$33.00", stock: 29, ventas: 63, image: anillo14, simage: anillo14_2 },
  { id: 16, name: "Anillo sol y luna", category: "Anillos", type: "casual", price: "$32.00", stock: 47, ventas: 125, image: anillo15, simage: anillo15_2 },
  { id: 17, name: "Anillo dulce corazón", category: "Anillos", type: "convencional", price: "$170.00", stock: 7, ventas: 50, image: anillo16, simage: anillo16_2 },
  { id: 18, name: "Anillo trebol de 4 hojas", category: "Anillos", type: "convencional", price: "$44.00", stock: 23, ventas: 69, image: anillo17, simage: anillo17_2 },
  { id: 19, name: "Anillo hiver", category: "Anillos", type: "convencional", price: "$185.00", stock: 6, ventas: 32, image: anillo18, simage: anillo18_2 },
  { id: 20, name: "Anillo de plata con forma de girasol", category: "Anillos", type: "casual", price: "$25.00", stock: 58, ventas: 112, image: anillo19, simage: anillo19_2 },


];



export default productos;