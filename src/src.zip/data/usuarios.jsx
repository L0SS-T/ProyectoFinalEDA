const usuarios = [{
    id: 1,
    nombre: "Juan",
    apellido: "Perez",
    correo: "juan.perez@gmail.com",
    password: "contraseña123",
    dni: 12345678,
    isActive: true,
    isAdmin: false
},
{
    id: 2,
    nombre: "Maria",
    apellido: "Gonzales",
    correo: "maria.gonzales@gmail.com",
    password: "contraseña456",
    dni: 90123456,
    isActive: true,  
    isAdmin: false
},
{
    id: 3,
    nombre: "Luis",
    apellido: "Rodriguez",
    correo: "luis.rodriguez@gmail.com",
    password: "contraseña789",
    dni: 78901234,
    isActive: true, 
    isAdmin: false
}, 
{
    id: 4,
    nombre: "Admin",
    apellido: "",
    correo: "admin@gmail.com",
    password: "admin1234",
    dni: 11111111,
    isActive: true,
    isAdmin: true
}]


export default usuarios