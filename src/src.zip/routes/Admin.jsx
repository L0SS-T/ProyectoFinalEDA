import AdminDashboard from "../components/AdminDashboard/AdminDashboard"

export default function Admin() {
  return (
    <>
     <AdminDashboard/>
    </>
  )
}