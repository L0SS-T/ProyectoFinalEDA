import ListadoOrdenes from "../components/ListadoOrdenes/ListadoOrdenes";

const ListadoOrdenesPage = ()=>{
    return(
            <ListadoOrdenes/>
    )
}
export default ListadoOrdenesPage;